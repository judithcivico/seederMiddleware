<?php
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PokemonController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('pokemon.welcome');
});

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);

Route::resource('pokemon', PokemonController::class);

Route::get('/user', function () {
    return view('pokemon.user');
})->name('user');

Route::middleware(['auth', 'user:admin'])->group(function () {
    Route::get("/admin", [AuthController::class, 'adminHome'])->name('admin.dashboard');
});

Route::middleware(['auth', 'user:user'])->group(function () {
    Route::get("/home", [AuthController::class, 'userHome'])->name('user.dashboard');
});

?>
