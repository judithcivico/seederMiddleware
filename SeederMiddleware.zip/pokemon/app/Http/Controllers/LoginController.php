<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;

class LoginController extends Controller
{
    public function login(Request $request){
        $input = $request->all();

        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        // si les dades introduides son correctes
        if (auth()->attempt(['email' => $input["email"], 'password' => $input['password']])) {
            $user = auth()->user();
            // si el rol del usuari es admin
            if ($user->role == 'admin') {
                return redirect()->route('pokemon.index');
                //si el rol del usuari es usuari
            } elseif ($user->role == 'user') {
                return redirect()->route('pokemon.user');
            }
        }
        //si les dades son incorrestes retorna error
        return redirect()
            ->route('pokemon.login')
            ->with("error", 'Datos incorrectos');
    }
}

