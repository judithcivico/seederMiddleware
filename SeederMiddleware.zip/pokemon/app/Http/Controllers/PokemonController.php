<?php

namespace App\Http\Controllers;

use App\Models\PokemonModel;
use Illuminate\Http\Request;

class PokemonController extends Controller
{
    public function index()
    {
        // mostra la lista de tots els pokemons
        $pokemons = PokemonModel::all();
        return view('pokemon.index', compact('pokemons'));
    }

    public function create()
    {
        // mostra el formulari par crear un nou pokemon
        return view('pokemon.create');
    }

    public function store(Request $request)
    {
        // guardar base dades
        $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'required|max:255',
            'tamaño' => 'required|max:255',
            'peso' => 'required|max:255',
        ]);

        PokemonModel::create([
            'nombre' => $request->input('nombre'),
            'tipo' => $request->input('tipo'),
            'tamaño' => $request->input('tamaño'),
            'peso' => $request->input('peso'),
        ]);

        return redirect()->route('pokemon.index')->with('success', 'Pokémon creado correctamente');
    }

    public function show($id)
    {
        // mostra els detalls de un pokemon especific
        $pokemon = PokemonModel::findOrFail($id);
        return view('pokemon.show', compact('pokemon'));
    }

    public function edit($id)
    {
        // mostra el formulari par editar un pokemon especific
        $pokemon = PokemonModel::findOrFail($id);
        return view('pokemon.edit', compact('pokemon'));
    }

    public function update(Request $request, $id)
    {
        // actualiza el pokemon
        $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'required|max:255',
            'tamaño' => 'required|max:255',
            'peso' => 'required|max:255',
        ]);

        $pokemon = PokemonModel::findOrFail($id);
        $pokemon->update($request->all());

        return redirect()->route('pokemon.index')->with('success', 'Pokémon actualizado correctamente');
    }

    public function destroy($id)
    {
        // elimina el pokemon
        $pokemon = PokemonModel::find($id);
        $pokemon->delete();

        return redirect()->route('pokemon.index')->with('success', 'Pokémon eliminado correctamente');
    }
}
