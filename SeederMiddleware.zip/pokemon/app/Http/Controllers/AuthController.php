<?php
// En app\Http\Controllers\AuthController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // form de login
    public function showLoginForm()
    {
        return view('pokemon.login');
    }
    // pantalla usuari
    public function userHome()
    {
        return view('pokemon.user');
    }
    // pantalla admin
    public function adminHome()
    {
        return view('pokemon.admin');
    }
}
?>