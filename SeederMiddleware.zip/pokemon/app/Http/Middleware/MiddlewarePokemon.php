<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PokemonAccessMiddleware
{
    public function handle($request, Closure $next)
    {
        // Verificar si el usuario está autenticado
        if (Auth::check()) {
            // Obtener el usuario autenticado
            $user = Auth::user();

            // Verificar si el usuario es administrador (puedes adaptar esto según tu estructura de base de datos)
            if ($user->isAdmin) {
                // Si es administrador, permitir el acceso a la vista del administrador
                return $next($request);
            } else {
                // Si no es administrador, redirigir a la vista del usuario normal
                return redirect()->route('pokemon.user');
            }
        }

        // Si el usuario no está autenticado, redirigir al inicio de sesión
        return redirect()->route('login');
    }
}
