<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Usuarios;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // creem un usuari admin
        Usuarios::create([
            'name' => 'admin',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('1234'), // xifrar la contrasenya
            'is_admin' => 1,
        ]);

        // creem un usuari normal
        Usuarios::create([
            'name' => 'judith',
            'email' => 'judith@gmail.com',
            'password' => bcrypt('1234'),
            'is_admin' => 0,
        ]);

    }
}
