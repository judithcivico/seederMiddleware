<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //libreria nos permite hacer insert
use Illuminate\Support\Str; //liberaria para funciones str

class PokemonSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        $tipos = ['agua', 'fuego', 'tierra'];

        for($i =0; $i<=9; $i++)
        {
            DB::table('pokemon')->insert([
                'nombre' => Str::random(10), // nombre aleatorio de 10 caracteres
                'tipo' => $tipos[array_rand($tipos)], // selecciona un tipo de la lista
                'tamaño' => rand(1, 10), // genera un tamaño aleatorio entre 1 y 10
                'peso' => rand(5, 200) / 10, // genera un peso aleatorio entre 5 y 200 con un decimal
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
