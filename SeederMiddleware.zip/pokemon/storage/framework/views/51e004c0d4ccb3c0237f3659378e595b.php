<body>
    <h2>Login</h2>
    <form action="/pokemon" method="post">
        <label for="username">Usuario:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br>
        <button type="submit">Iniciar sesión</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pokemon\resources\views/pokemon/login.blade.php ENDPATH**/ ?>