<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
</head>
<body>
    <h2>Login</h2>

    <?php if(session('error')): ?>
        <div style="color: red;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label for="email">Correo:</label>
        <input type="text" id="email" name="email" required><br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br>

        <button type="submit">Iniciar sesión</button>
    </form>
</body>
</html>
<?php /**PATH C:\xamp\htdocs\pokemon\resources\views/pokemon/login.blade.php ENDPATH**/ ?>